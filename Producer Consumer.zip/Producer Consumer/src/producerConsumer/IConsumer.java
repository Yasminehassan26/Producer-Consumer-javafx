package producerConsumer;

public interface IConsumer extends Runnable {
    public void consumeProduct();
}
