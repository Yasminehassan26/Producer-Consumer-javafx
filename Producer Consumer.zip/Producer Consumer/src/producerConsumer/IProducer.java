package producerConsumer;

public interface IProducer {
    public void produceProduct( Machine machine );
}
